module MyLib (someFunc) where

import Control.Applicative
import Control.Monad
import Control.Monad.State
import Data.List (intercalate)
import Data.Maybe (fromMaybe)

someFunc :: IO ()
someFunc = putStrLn "someFunc"


type Env = [(String, Atom)]

type LispM a = StateT Env IO a

data Atom = Num Int 
        | Bool Bool
        | Char Char
        | String String
        | Cons Atom Atom
        | Add Atom Atom
        | Sub Atom Atom
        | Mul Atom Atom
        | Div Atom Atom


eval :: Atom -> LispM Atom
-- eval :: Atom -> Int
eval (Num n) = n
eval (Add a b) = eval a + eval b
eval (Sub a b) = eval a - eval b
eval (Mul a b) = eval a * eval b
eval (Div a b) = div (eval a) (eval b)
eval (Bool b) = fromEnum b
eval (Char c) = ord c
eval (String s) = length s
eval (Cons a b) = Cons (eval a) (eval b)

eval (Atom "quote" List [x]) = return x
eval (Atom "if" List [test, conseq, alt]) = do
    result <- eval test
    case result of
        Bool True  -> eval conseq
        Bool False -> eval alt
        _          -> error "Test expression must evaluate to a boolean"
eval (Atom "lambda" List (Atom arg : body)) = return $ Lambda arg body
eval (List (Atom func : args)) = do
    funcVal <- eval (Atom func)
    argVals <- mapM eval args
    apply funcVal argVals

apply :: LispVal -> [LispVal] -> LispM LispVal
apply (Lambda arg body) args = do
    let newEnv = [(arg, head args)] -- простая реализация без захвата окружения
    evalState (mapM eval body) newEnv
apply _ _ = error "Not a function"

-- Арифметические операции
arithmetic :: String -> [Atom] -> LispM Atom
arithmetic op args = case op of
    "+" -> return $ Number $ sum $ map unpackNumber args
    "-" -> return $ Number $ foldl1 (-) $ map unpackNumber args
    "*" -> return $ Number $ product $ map unpackNumber args
    "/" -> return $ Number $ foldl1 div $ map unpackNumber args

unpackNumber :: Atom -> Integer
unpackNumber (Number n) = n
unpackNumber _          = error "Expected a number"

-- Сравнения и логические операции
comparison :: String -> [Atom] -> LispM Atom
comparison op args = case op of
    ">"  -> return . Bool $ all (> 0) [unpackNumber x | x <- args]
    "<"  -> return . Bool $ all (< 0) [unpackNumber x | x <- args]
    "==" -> return . Bool $ all (== head args) args

-- Парсинг (упрощённый)
parse :: String -> Atom
parse input = List [Atom "quote", String input] -- Упрощенная версия

-- Пример использования
runLisp :: String -> IO ()
runLisp input = evalStateT (eval (parse input)) []